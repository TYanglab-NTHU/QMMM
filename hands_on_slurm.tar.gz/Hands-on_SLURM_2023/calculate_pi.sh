#!/bin/bash

##source /etc/profile.d/dicos-environment-modules.sh
module load app/anaconda3/4.9.2
python calculate_pi.py

