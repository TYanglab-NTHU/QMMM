#!/bin/bash

date
echo "Hello World DiCOS Users!"
hostname

