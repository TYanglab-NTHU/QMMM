# Load modules for Python coding
import sys                      # IO Basics
import glob                     # wild cards in file names
import os                       # access file system
import subprocess               # call the shell

# Load modules and prepare to read the CCS data base
# from ccdc          import io                    # read crystal structures
# from ccdc.search   import TextNumericSearch     # search by text or numbers
# from ccdc.molecule import Molecule, Atom, Bond  # build a molecule
# csd_reader = io.EntryReader('CSD')

print("Hello")