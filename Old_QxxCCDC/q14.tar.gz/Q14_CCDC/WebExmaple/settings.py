def init():
    global myList
    myList = []